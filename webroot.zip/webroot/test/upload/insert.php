<!doctype html>
<?php  
header("Content-type:text/html;charset=utf-8");
include"session_check.php";
include_once"connect_mysql.php";
$lesson=$_POST['select10'];//作业民day1
echo $lesson;
    $name=$_SESSION['name']; //学生名
$name=iconv("UTF-8","gb2312", $name);
$number=$_SESSION['number'];//学号
$lesson1=$_POST['select11'];//课程号
$type=$_SESSION['type'];
$myfile = fopen("./lesson/$lesson1/student_work/$lesson/$number$name.txt", "a") or die("Unable to open file!");

$m=0;
for($j=0;$j<10;$j++){
	$select[$m]=$_POST['select'.$j];
	$select1=iconv("UTF-8","gb2312", $_POST['select'.$j]);
	fwrite($myfile, $select1."\r\n");
	echo $select[$m];
	$m+=1;
}
for($i=1;$i<6;$i++){
	echo $_POST["number".$i];
	$select[$m]=$_POST["number".$i];
	$input=iconv("UTF-8","gb2312", $_POST["number".$i]);
	fwrite($myfile, $input."\r\n");
	echo $select[$m];
	$m+=1;
}
$sql1="INSERT INTO `housework`(`usertype`, `number`, `work`, `课程代码`, `select1`, `select2`, `select3`, `select4`, `select5`, `select6`, `select7`, `select8`, `select9`, `select10`, `text1`, `text2`, `text3`, `text4`, `text5`) VALUES ('$type','$number','$lesson','$lesson1','$select[0]','$select[1]','$select[2]','$select[3]','$select[4]','$select[5]','$select[6]','$select[7]','$select[8]','$select[9]','$select[10]','$select[11]','$select[12]','$select[13]','$select[14]') ";
$result1 = mysql_query($sql1,$conn);
$sql="SELECT  `select1`, `select2`, `select3`, `select4`, `select5`, `select6`, `select7`, `select8`, `select9`, `select10`, `text1`, `text2`, `text3`, `text4`, `text5` FROM `housework` WHERE usertype='teacher' and work='$lesson' and 课程代码='$lesson1'";
$result= mysql_query($sql,$conn);
$arr=mysql_fetch_row($result);
print_r($arr);
print_r($select);
$score=0;
for($n=0;$n<15;$n++){
	if($arr[$n]==$select[$n]){
		echo "相等";
		$score+=1;
	}else{
		echo "buxd";
	}
}
echo $score;
 $sql2 = "UPDATE housework
        SET score='$score'
        WHERE number='$number' and work='$lesson' and 课程代码='$lesson1'";
	$result = mysql_query($sql2,$conn);  
//1.接收提交文件的用户  
fclose($myfile);
 echo "<script>alert('客观题得分为$score'); history.go(-1);</script>";
?>