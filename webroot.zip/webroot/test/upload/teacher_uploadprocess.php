<!doctype html>
<?php  
header("Content-type:text/html;charset=utf-8");
include"session_check.php";
include_once"connect_mysql.php";
$type=$_SESSION['type'];
$work=$_POST['work'];
$number=$_SESSION['lessonnumber'];
$number1=$_SESSION['number'];
$asdfaf=$_POST["select2"];
$m=0;
for($j=0;$j<10;$j++){
	$select[$m]=$_POST['select'.$j];
	$m+=1;
}
for($i=1;$i<6;$i++){
	$select[$m]=$_POST["number".$i];
	$m+=1;
}
$sql="INSERT INTO `housework`(`usertype`, `number`, `work`, `课程代码`, `select1`, `select2`, `select3`, `select4`, `select5`, `select6`, `select7`, `select8`, `select9`, `select10`, `text1`, `text2`, `text3`, `text4`, `text5`) VALUES ('$type','$number1','$work','$number','$select[0]','$select[1]','$select[2]','$select[3]','$select[4]','$select[5]','$select[6]','$select[7]','$select[8]','$select[9]','$select[10]','$select[11]','$select[12]','$select[13]','$select[14]') ";
$result = mysql_query($sql,$conn);
if($result){

    //1.接收提交文件的用户  

    //获取文件的大小  
    $file_size=$_FILES['myfile']['size'];  
    if($file_size>2*1024*1024) {  
        echo "文件过大，不能上传大于2M的文件";  
        exit();  
    }  
  
    $file_type=$_FILES['myfile']['type'];   
    if($file_type!="text/plain" ) {  
        echo "文件类型只能为text格式";  
        exit();  
    }
    echo $file_type;  
    //判断是否上传成功（是否使用post方式上传）  
    if(is_uploaded_file($_FILES['myfile']['tmp_name'])) {  
         $result=move_uploaded_file($_FILES['myfile']['tmp_name'],"./lesson/"."$number"."/housework/"."$work.txt"); 
		$dir = iconv("UTF-8", "GBK", "./lesson/"."$number"."/student_work/"."$work");
        if (!file_exists($dir)){
            mkdir ($dir,0777,true);
            echo '创建文件夹成功';
        } else {
            echo '需创建的文件夹已经存在';
        }
		echo "<script>alert('发布成功'); history.go(-1);</script>";
    } else {  
        echo "<script>alert('发布失败'); history.go(-1);</script>"; 
    } 
}else{
	echo "<script>alert('发布失败'); history.go(-1);</script>"; 
}
?>